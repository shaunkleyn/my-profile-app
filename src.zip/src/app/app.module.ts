import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NgwWowModule } from 'ngx-wow';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AdminLayoutComponent } from './layouts/admin-layout/admin-layout.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatTooltipModule } from '@angular/material/tooltip';
import { NavbarComponent } from './components/navbar/navbar.component';
import { SidebarComponent } from './components/sidebar/sidebar.component';
import { AboutMeComponent } from './about-me/about-me.component';

@NgModule({
   declarations: [
      AppComponent,
      DashboardComponent,
      AdminLayoutComponent,
      NavbarComponent,
      SidebarComponent,
      AboutMeComponent
   ],
   imports: [
      BrowserModule,
      AppRoutingModule,
      NgwWowModule,
      BrowserAnimationsModule,
      MatTooltipModule
   ],
   providers: [],
   bootstrap: [
      AppComponent
   ]
})
export class AppModule { }
